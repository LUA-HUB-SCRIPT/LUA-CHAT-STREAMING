# AHZA LIVE CHAT

Multi-platform live chat monitor for streamers.

## Targets
- Android 10+ (API 29+)
- Windows 10/11 (x64)
- Twitch: channel link or OAuth token
- YouTube: API key + live video ID
- TikTok: adapter interface reserved for official API access
- Desktop notification
- Hidden chat mode
- Windows Ctrl+F1 toggle
- Android floating overlay service

## Security
Never commit API keys or OAuth tokens. Use local settings only.

## Twitch
Link mode connects as an anonymous Twitch chat reader where permitted.
Token mode uses Twitch IRC authentication.

## YouTube
Create a YouTube Data API v3 key and enter it in the app. Enter the live video's ID.

## TikTok
The project intentionally does not bypass TikTok authentication or scrape private endpoints.
Implement the adapter only when you have an authorized official API capability.

## Windows build
Install .NET 8 SDK, then:
dotnet build windows/AHZA.LiveChat.Windows.csproj

Run:
dotnet run --project windows/AHZA.LiveChat.Windows.csproj

## Android build
Open android/ in Android Studio or use Gradle:
gradle -p android assembleDebug

GitHub Actions is included in .github/workflows/build.yml.
