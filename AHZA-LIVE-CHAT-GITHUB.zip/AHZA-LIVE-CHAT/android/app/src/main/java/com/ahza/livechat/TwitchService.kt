package com.ahza.livechat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.net.URI
import java.net.http.HttpClient
import java.net.http.WebSocket
import java.util.concurrent.CompletionStage

class TwitchService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification("Waiting for Twitch chat"))
        scope.launch { connect() }
    }

    private suspend fun connect() {
        val channel = ChatState.channel ?: return
        val client = HttpClient.newHttpClient()
        val listener = object : WebSocket.Listener {
            private val buffer = StringBuilder()
            override fun onOpen(ws: WebSocket) {
                ws.request(1)
                ws.sendText("CAP REQ :twitch.tv/tags twitch.tv/commands", true)
                val token = ChatState.token.removePrefix("oauth:")
                if (token.isBlank()) {
                    ws.sendText("PASS SCHMOOPIIE", true)
                    ws.sendText("NICK justinfan${(10000..99999).random()}", true)
                } else {
                    ws.sendText("PASS oauth:$token", true)
                    ws.sendText("NICK justinfan${(10000..99999).random()}", true)
                }
                ws.sendText("JOIN #$channel", true)
            }
            override fun onText(ws: WebSocket, data: CharSequence, last: Boolean): CompletionStage<*> {
                buffer.append(data)
                if (last) {
                    val text = buffer.toString()
                    buffer.clear()
                    text.split("\r\n").forEach { line ->
                        if (line.startsWith("PING")) ws.sendText("PONG :tmi.twitch.tv", true)
                        val m = Regex("PRIVMSG #[^ ]+ :(.*)").find(line)
                        if (m != null) {
                            val msg = m.groupValues[1]
                            ChatState.messages.add("[Twitch] $msg")
                            notifyChat(msg)
                        }
                    }
                }
                ws.request(1)
                return null
            }
        }
        client.newWebSocketBuilder().buildAsync(
            URI.create("wss://irc-ws.chat.twitch.tv:443"), listener
        ).join()
    }

    private fun notifyChat(msg: String) {
        val n = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        n.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            notification(msg))
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, "chat")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AHZA Live Chat")
            .setContentText(text.take(120))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

    private fun createChannel() {
        val n = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        n.createNotificationChannel(NotificationChannel("chat", "Live Chat", NotificationManager.IMPORTANCE_DEFAULT))
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
