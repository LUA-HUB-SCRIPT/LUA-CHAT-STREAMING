package com.ahza.livechat

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    private var window: WindowManager? = null
    private var view: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) return
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val text = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC111111.toInt())
            textSize = 14f
            setPadding(20, 20, 20, 20)
            text = "AHZA LIVE CHAT\\n" + ChatState.messages.takeLast(8).joinToString("\\n")
        }
        view = text
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            650, 500, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 20; p.y = 100
        window?.addView(text, p)
    }

    override fun onDestroy() {
        view?.let { window?.removeView(it) }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
