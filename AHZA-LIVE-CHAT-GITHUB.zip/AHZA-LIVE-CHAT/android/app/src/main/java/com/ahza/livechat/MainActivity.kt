package com.ahza.livechat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        val twitchLink = findViewById<EditText>(R.id.twitchLink)
        val token = findViewById<EditText>(R.id.twitchToken)
        val status = findViewById<TextView>(R.id.status)

        findViewById<Button>(R.id.connect).setOnClickListener {
            val channel = TwitchParser.channelFromUrl(twitchLink.text.toString())
            if (channel.isNullOrBlank()) {
                status.text = "Status: invalid Twitch channel link"
                return@setOnClickListener
            }
            ChatState.channel = channel
            ChatState.token = token.text.toString().trim()
            status.text = "Status: ready for Twitch #$channel"
            startService(Intent(this, TwitchService::class.java))
        }

        findViewById<Button>(R.id.overlay).setOnClickListener {
            startService(Intent(this, OverlayService::class.java))
        }
    }
}

object ChatState {
    @Volatile var channel: String? = null
    @Volatile var token: String = ""
    val messages = java.util.Collections.synchronizedList(mutableListOf<String>())
}

object TwitchParser {
    fun channelFromUrl(raw: String): String? {
        var s = raw.trim().removeSuffix("/")
        s = s.substringAfter("twitch.tv/", s)
        s = s.substringAfter("www.twitch.tv/", s)
        if (s.contains("/")) s = s.substringBefore("/")
        if (!Regex("^[A-Za-z0-9_]{4,25}$").matches(s)) return null
        return s.lowercase()
    }
}
