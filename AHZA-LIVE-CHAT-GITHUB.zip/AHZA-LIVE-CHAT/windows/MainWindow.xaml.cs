using System.Net.WebSockets;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Runtime.InteropServices;

namespace AHZA.LiveChat;

public partial class MainWindow : Window
{
    ClientWebSocket? ws;
    const int HOTKEY_ID = 9001;
    const uint MOD_CONTROL = 0x0002;
    const uint VK_F1 = 0x70;

    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    public MainWindow()
    {
        InitializeComponent();
        SourceInitialized += (_, _) => {
            var handle = new WindowInteropHelper(this).Handle;
            RegisterHotKey(handle, HOTKEY_ID, MOD_CONTROL, VK_F1);
            HwndSource.FromHwnd(handle)!.AddHook(WndProc);
        };
    }

    IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == 0x0312 && wParam.ToInt32() == HOTKEY_ID)
        {
            Visibility = Visibility == Visibility.Visible ? Visibility.Hidden : Visibility.Visible;
            handled = true;
        }
        return IntPtr.Zero;
    }

    async void ConnectLink(object sender, RoutedEventArgs e)
    {
        var channel = TwitchChannel(TwitchBox.Text);
        if (channel == null) { MessageBox.Show("Invalid Twitch channel."); return; }
        await ConnectTwitch(channel, null);
    }

    async void TokenMode(object sender, RoutedEventArgs e)
    {
        var token = Microsoft.VisualBasic.Interaction.InputBox(
            "Paste Twitch OAuth token. It is kept only for this session.",
            "Twitch OAuth", "");
        var channel = TwitchChannel(TwitchBox.Text);
        if (channel == null) { MessageBox.Show("Invalid Twitch channel."); return; }
        await ConnectTwitch(channel, token);
    }

    static string? TwitchChannel(string raw)
    {
        var s = raw.Trim().TrimEnd('/');
        var marker = "twitch.tv/";
        var i = s.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (i >= 0) s = s[(i + marker.Length)..];
        if (s.Contains('/')) s = s[..s.IndexOf('/')];
        return System.Text.RegularExpressions.Regex.IsMatch(s, "^[A-Za-z0-9_]{4,25}$")
            ? s.ToLowerInvariant() : null;
    }

    async Task ConnectTwitch(string channel, string? token)
    {
        ws?.Dispose();
        ws = new ClientWebSocket();
        await ws.ConnectAsync(new Uri("wss://irc-ws.chat.twitch.tv:443"), CancellationToken.None);
        await Send($"CAP REQ :twitch.tv/tags twitch.tv/commands");
        if (string.IsNullOrWhiteSpace(token))
        {
            await Send("PASS SCHMOOPIIE");
            await Send("NICK justinfan" + Random.Shared.Next(10000, 99999));
        }
        else
        {
            await Send($"PASS oauth:{token.Trim().Replace("oauth:", "")}");
            await Send("NICK justinfan" + Random.Shared.Next(10000, 99999));
        }
        await Send($"JOIN #{channel}");
        _ = ReceiveLoop();
    }

    async Task Send(string s) =>
        await ws!.SendAsync(Encoding.UTF8.GetBytes(s + "\r\n"), WebSocketMessageType.Text, true, CancellationToken.None);

    async Task ReceiveLoop()
    {
        var buf = new byte[8192];
        while (ws?.State == WebSocketState.Open)
        {
            var r = await ws.ReceiveAsync(buf, CancellationToken.None);
            var text = Encoding.UTF8.GetString(buf, 0, r.Count);
            foreach (var line in text.Split("\r\n", StringSplitOptions.RemoveEmptyEntries))
            {
                if (line.StartsWith("PING"))
                {
                    await Send("PONG :tmi.twitch.tv");
                    continue;
                }
                var idx = line.IndexOf(" PRIVMSG ");
                if (idx >= 0)
                {
                    var colon = line.IndexOf(" :", idx);
                    if (colon >= 0)
                    {
                        var msg = line[(colon + 2)..];
                        Dispatcher.Invoke(() => {
                            ChatList.Items.Add($"[Twitch] {msg}");
                            if (ChatList.Items.Count > 100) ChatList.Items.RemoveAt(0);
                        });
                        Notify(msg);
                    }
                }
            }
        }
    }

    void Notify(string msg)
    {
        Dispatcher.Invoke(() => {
            if (Visibility != Visibility.Visible)
                System.Media.SystemSounds.Asterisk.Play();
        });
    }

    protected override void OnClosed(EventArgs e)
    {
        var h = new WindowInteropHelper(this).Handle;
        UnregisterHotKey(h, HOTKEY_ID);
        ws?.Dispose();
        base.OnClosed(e);
    }
}
