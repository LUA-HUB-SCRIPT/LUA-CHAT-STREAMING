using System.Windows;

namespace AHZA.LiveChat;
public partial class App : Application { }
