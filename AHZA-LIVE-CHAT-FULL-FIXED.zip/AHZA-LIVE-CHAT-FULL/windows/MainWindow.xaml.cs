using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Interop;

namespace AHZA.LiveChat;

public partial class MainWindow : Window
{
    private ClientWebSocket? _socket;

    private const int HotkeyId = 9001;
    private const uint ModControl = 0x0002;
    private const uint VkF1 = 0x70;

    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(
        IntPtr hWnd,
        int id,
        uint fsModifiers,
        uint vk);

    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(
        IntPtr hWnd,
        int id);

    public MainWindow()
    {
        InitializeComponent();

        SourceInitialized += (_, _) =>
        {
            var handle =
                new WindowInteropHelper(this).Handle;

            RegisterHotKey(
                handle,
                HotkeyId,
                ModControl,
                VkF1);

            HwndSource
                .FromHwnd(handle)!
                .AddHook(WndProc);
        };
    }

    private IntPtr WndProc(
        IntPtr hwnd,
        int msg,
        IntPtr wParam,
        IntPtr lParam,
        ref bool handled)
    {
        if (msg == 0x0312 &&
            wParam.ToInt32() == HotkeyId)
        {
            Visibility =
                Visibility == Visibility.Visible
                    ? Visibility.Hidden
                    : Visibility.Visible;

            handled = true;
        }

        return IntPtr.Zero;
    }

    private async void ConnectLink(
        object sender,
        RoutedEventArgs e)
    {
        var channel =
            ParseTwitchChannel(TwitchBox.Text);

        if (channel == null)
        {
            MessageBox.Show(
                "Invalid Twitch channel.",
                "AHZA Live Chat");

            return;
        }

        await ConnectTwitch(channel, null);
    }

    private async void TokenMode(
        object sender,
        RoutedEventArgs e)
    {
        var token =
            Microsoft.VisualBasic.Interaction.InputBox(
                "Enter your Twitch OAuth token.",
                "Twitch OAuth",
                "");

        if (string.IsNullOrWhiteSpace(token))
            return;

        var channel =
            ParseTwitchChannel(TwitchBox.Text);

        if (channel == null)
        {
            MessageBox.Show(
                "Invalid Twitch channel.",
                "AHZA Live Chat");

            return;
        }

        await ConnectTwitch(channel, token);
    }

    private static string? ParseTwitchChannel(
        string raw)
    {
        var value =
            raw.Trim().TrimEnd('/');

        const string marker =
            "twitch.tv/";

        var index =
            value.IndexOf(
                marker,
                StringComparison.OrdinalIgnoreCase);

        if (index >= 0)
        {
            value =
                value[(index + marker.Length)..];
        }

        if (value.Contains('/'))
        {
            value =
                value[..value.IndexOf('/')];
        }

        return Regex.IsMatch(
            value,
            "^[A-Za-z0-9_]{4,25}$")
            ? value.ToLowerInvariant()
            : null;
    }

    private async Task ConnectTwitch(
        string channel,
        string? token)
    {
        _socket?.Dispose();

        _socket =
            new ClientWebSocket();

        await _socket.ConnectAsync(
            new Uri(
                "wss://irc-ws.chat.twitch.tv:443"),
            CancellationToken.None);

        await Send(
            "CAP REQ :twitch.tv/tags twitch.tv/commands");

        var cleanToken =
            token?
                .Trim()
                .Replace("oauth:", "");

        if (string.IsNullOrWhiteSpace(cleanToken))
        {
            await Send("PASS SCHMOOPIIE");
        }
        else
        {
            await Send($"PASS oauth:{cleanToken}");
        }

        await Send(
            "NICK justinfan" +
            Random.Shared.Next(10000, 99999));

        await Send($"JOIN #{channel}");

        _ = ReceiveLoop();
    }

    private async Task Send(string value)
    {
        if (_socket == null)
            return;

        var bytes =
            Encoding.UTF8.GetBytes(
                value + "\r\n");

        await _socket.SendAsync(
            bytes,
            WebSocketMessageType.Text,
            true,
            CancellationToken.None);
    }

    private async Task ReceiveLoop()
    {
        if (_socket == null)
            return;

        var buffer =
            new byte[8192];

        while (
            _socket.State ==
            WebSocketState.Open)
        {
            var result =
                await _socket.ReceiveAsync(
                    buffer,
                    CancellationToken.None);

            if (result.MessageType ==
                WebSocketMessageType.Close)
            {
                break;
            }

            var text =
                Encoding.UTF8.GetString(
                    buffer,
                    0,
                    result.Count);

            foreach (
                var line in text.Split(
                    "\r\n",
                    StringSplitOptions.RemoveEmptyEntries))
            {
                if (line.StartsWith("PING"))
                {
                    await Send(
                        "PONG :tmi.twitch.tv");

                    continue;
                }

                var marker =
                    " PRIVMSG ";

                var start =
                    line.IndexOf(marker);

                if (start < 0)
                    continue;

                var messageStart =
                    line.IndexOf(
                        " :",
                        start);

                if (messageStart < 0)
                    continue;

                var message =
                    line[(messageStart + 2)..];

                Dispatcher.Invoke(() =>
                {
                    ChatList.Items.Add(
                        "[Twitch] " + message);

                    if (ChatList.Items.Count > 100)
                    {
                        ChatList.Items.RemoveAt(0);
                    }

                    if (
                        Visibility !=
                        Visibility.Visible)
                    {
                        System.Media
                            .SystemSounds
                            .Asterisk
                            .Play();
                    }
                });
            }
        }
    }

    protected override void OnClosed(
        EventArgs e)
    {
        var handle =
            new WindowInteropHelper(this)
                .Handle;

        UnregisterHotKey(
            handle,
            HotkeyId);

        _socket?.Dispose();

        base.OnClosed(e);
    }
}
