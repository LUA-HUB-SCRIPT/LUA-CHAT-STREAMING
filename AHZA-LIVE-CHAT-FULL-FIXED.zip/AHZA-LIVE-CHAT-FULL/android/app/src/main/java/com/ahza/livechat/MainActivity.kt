package com.ahza.livechat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestNotificationPermission()

        val twitchLink = findViewById<EditText>(R.id.twitchLink)
        val twitchToken = findViewById<EditText>(R.id.twitchToken)
        val status = findViewById<TextView>(R.id.status)

        findViewById<Button>(R.id.connect).setOnClickListener {
            val channel = TwitchParser.channelFromUrl(twitchLink.text.toString())

            if (channel == null) {
                status.text = "Status: invalid Twitch channel"
                return@setOnClickListener
            }

            ChatState.channel = channel
            ChatState.token = twitchToken.text.toString().trim()

            val intent = Intent(this, TwitchService::class.java)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }

            status.text = "Status: connected to #$channel"
        }

        findViewById<Button>(R.id.overlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                status.text = "Allow overlay permission, then press the button again."
                return@setOnClickListener
            }

            startService(Intent(this, OverlayService::class.java))
            status.text = "Status: overlay opened"
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }
    }
}
