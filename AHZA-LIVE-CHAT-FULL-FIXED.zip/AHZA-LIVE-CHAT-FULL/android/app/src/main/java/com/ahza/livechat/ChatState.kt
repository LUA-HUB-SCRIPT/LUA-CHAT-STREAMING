package com.ahza.livechat

import java.util.Collections

object ChatState {
    @Volatile var channel: String? = null
    @Volatile var token: String = ""
    val messages = Collections.synchronizedList(mutableListOf<String>())
}
