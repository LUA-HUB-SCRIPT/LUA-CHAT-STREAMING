package com.ahza.livechat

object TwitchParser {
    fun channelFromUrl(raw: String): String? {
        var s = raw.trim().removeSuffix("/")

        s = when {
            s.contains("twitch.tv/", ignoreCase = true) ->
                s.substringAfter("twitch.tv/", s)
            else -> s
        }

        if (s.contains("/")) {
            s = s.substringBefore("/")
        }

        return if (Regex("^[A-Za-z0-9_]{4,25}$").matches(s)) {
            s.lowercase()
        } else {
            null
        }
    }
}
