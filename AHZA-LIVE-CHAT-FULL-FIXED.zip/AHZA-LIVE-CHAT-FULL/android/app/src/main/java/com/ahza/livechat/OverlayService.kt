package com.ahza.livechat

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlay: TextView? = null

    override fun onCreate() {
        super.onCreate()

        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xDD111111.toInt())
            textSize = 14f
            setPadding(20, 20, 20, 20)
            text = buildChatText()
        }

        val type =
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

        val params = WindowManager.LayoutParams(
            650,
            500,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.END
        params.x = 20
        params.y = 100

        windowManager?.addView(overlay, params)
    }

    private fun buildChatText(): String {
        val messages = synchronized(ChatState.messages) {
            ChatState.messages.takeLast(10)
        }

        return if (messages.isEmpty()) {
            "AHZA LIVE CHAT\n\nNo messages yet."
        } else {
            "AHZA LIVE CHAT\n\n" + messages.joinToString("\n")
        }
    }

    override fun onDestroy() {
        overlay?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }

        overlay = null
        windowManager = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
