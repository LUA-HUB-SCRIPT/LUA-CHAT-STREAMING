package com.ahza.livechat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

class TwitchService : Service() {

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var socket: WebSocket? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, serviceNotification("Connecting to Twitch..."))
        connect()
    }

    private fun connect() {
        val channel = ChatState.channel ?: return

        val request = Request.Builder()
            .url("wss://irc-ws.chat.twitch.tv:443")
            .build()

        socket = client.newWebSocket(
            request,
            object : WebSocketListener() {

                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send("CAP REQ :twitch.tv/tags twitch.tv/commands")

                    val token = ChatState.token
                        .trim()
                        .removePrefix("oauth:")

                    if (token.isBlank()) {
                        webSocket.send("PASS SCHMOOPIIE")
                        webSocket.send("NICK justinfan${(10000..99999).random()}")
                    } else {
                        webSocket.send("PASS oauth:$token")
                        webSocket.send("NICK justinfan${(10000..99999).random()}")
                    }

                    webSocket.send("JOIN #$channel")
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    text.split("\r\n")
                        .filter { it.isNotBlank() }
                        .forEach { line -> handleLine(webSocket, line) }
                }

                override fun onFailure(
                    webSocket: WebSocket,
                    t: Throwable,
                    response: Response?
                ) {
                    updateForeground("Twitch connection failed")
                }

                override fun onClosed(
                    webSocket: WebSocket,
                    code: Int,
                    reason: String
                ) {
                    updateForeground("Twitch disconnected")
                }
            }
        )
    }

    private fun handleLine(webSocket: WebSocket, line: String) {
        if (line.startsWith("PING")) {
            webSocket.send("PONG :tmi.twitch.tv")
            return
        }

        val marker = " PRIVMSG "
        val start = line.indexOf(marker)

        if (start < 0) return

        val messageStart = line.indexOf(" :", start)

        if (messageStart < 0) return

        val message = line.substring(messageStart + 2).trim()

        if (message.isBlank()) return

        ChatState.messages.add("[Twitch] $message")

        if (ChatState.messages.size > 200) {
            ChatState.messages.removeAt(0)
        }

        notifyChat(message)
        updateForeground("Twitch: $message")
    }

    private fun notifyChat(message: String) {
        val manager =
            getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        val notification = NotificationCompat.Builder(this, "chat")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Twitch Live Chat")
            .setContentText(message.take(160))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        manager.notify(
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            notification
        )
    }

    private fun updateForeground(text: String) {
        val manager =
            getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        manager.notify(
            7,
            serviceNotification(text)
        )
    }

    private fun serviceNotification(text: String): Notification {
        return NotificationCompat.Builder(this, "chat")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AHZA Live Chat")
            .setContentText(text.take(160))
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        val manager =
            getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        manager.createNotificationChannel(
            NotificationChannel(
                "chat",
                "AHZA Live Chat",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    override fun onDestroy() {
        socket?.close(1000, "Service stopped")
        socket = null
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
