# AHZA LIVE CHAT

Multi-platform live-chat monitor.

## Targets
- Android 10+ (API 29+)
- Windows 10/11 x64
- Twitch: channel LINK or OAuth token
- YouTube: configuration fields included
- TikTok: official-API adapter placeholder
- Notifications when chat arrives
- Android floating overlay
- Windows Ctrl+F1 show/hide

## Android
Open `android/` in Android Studio, or build with:
`gradle -p android assembleDebug`

Minimum Android: 10 (API 29).

## Windows
Requires .NET 8 SDK:
`dotnet publish windows/AHZA.LiveChat.Windows.csproj -c Release -r win-x64 --self-contained false`

## Security
Do not commit API keys or OAuth tokens to GitHub.
